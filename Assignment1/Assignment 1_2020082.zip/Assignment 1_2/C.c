#include<stdio.h>
#include <stdlib.h>
void C(){
    exit(0);
}