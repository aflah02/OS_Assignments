#! /bin/bash
echo "Enter Month: "
read Month
echo "Enter Year: "
read Year
cal $Month $Year