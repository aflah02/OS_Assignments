Question 1:

Command - 
./1.sh <month> <year>

The Program requires a month and year to be passed via the command line and appropriate calendar is then printed

Question 2:

Command - 
./2.sh <operation> <num_1> <num_2> ... <num_n>

The program asks the user for the operation and then applies it to all the operands which follow it from left to right
The user can choose one of these operations - add, sub, mul, div, exp

Question 3a:

Command - 
./output_assignment_3_3a

The Program guides the user via a command line UI to do a bunch of operations on a Binary Tree (wrong type inputs may cause errors)

Question 3b:

Command - 
./output_assignment_3_3b

The Program guides the user via a command line UI to do a bunch of operations on a height balanced binary tree (AVL Tree) (wrong type inputs may cause errors)

Question 4:

Command - 
./output_assignment_3_4

The code will prompt the user for an input based on which the chosen sorting algorithm will be used on the given array

