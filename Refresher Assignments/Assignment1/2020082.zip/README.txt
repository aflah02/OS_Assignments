Question 1:

Command - 
./output_assignment_1_1 input.abc output.abc

Here input.abc is the input file with the proper extension and output.abc is the output file with the proper extension
The program will copy the contents from file A to B, if file B does not exist it will be created

Question 2:

Command - 
./output_assignment_1_2

Question 3:

Command - 
./output_assignment_1_3

The code first asks for 2 variables and swaps them via 2 method with and without using a temp variable
Then it asks for array elements and swaps their elements as well


Question 4:

Command - 
./output_assignment_1_4

The code prompts for a string input then it reverses it and prints the output

Question 5:

Command - 
./output_assignment_1_5

The code will prompt for array size and it's elements, the code then auto adds the 3 large values from the Question
and returns the position of the target inputted 

