Question 1:

Command - 
./output_assignment_2_1

The program auto generates the matrix given in Question
Then it prompts for input in self explanatory fashion

Question 2a:

Command - 
./output_assignment_2_2a

The Program guides the user via a command line UI to do a bunch of operations on the singly linked list (wrong type inputs may cause errors)

Question 2b:

Command - 
./output_assignment_2_2b

The Program guides the user via a command line UI to do a bunch of operations on the doubly linked list (wrong type inputs may cause errors)

Question 2c:

Command - 
./output_assignment_2_2c

The Program guides the user via a command line UI to choose stack or queue and do a bunch of operations (wrong type inputs may cause errors)

Question 3:

Command - 
./output_assignment_2_3

The user is prompted for input after the array is initialized and the commands are run according to the user choices

Question 5:

Command - 
./output_assignment_2_5

The code will prompt the user for an input based on which the chosen sorting algorithm will be used on the given array

